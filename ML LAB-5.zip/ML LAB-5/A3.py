import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error, r2_score
df = pd.read_csv("GiveMeSomeCredit.csv")
df = df.dropna()
X_all = df.drop(columns=["SeriousDlqin2yrs"])
y_all = df["SeriousDlqin2yrs"]
X_train_all, X_test_all, y_train_all, y_test_all = train_test_split(
    X_all, y_all, test_size=0.2, random_state=42
)
def train_linear_regression_all(X_train, y_train):
    model = LinearRegression()
    model.fit(X_train, y_train)
    return model
def evaluate_regression(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    rmse = mse ** 0.5  
    mape = mean_absolute_percentage_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    return mse, rmse, mape, r2
model_all = train_linear_regression_all(X_train_all, y_train_all)
y_train_pred_all = model_all.predict(X_train_all)
y_test_pred_all = model_all.predict(X_test_all)
train_metrics_all = evaluate_regression(y_train_all, y_train_pred_all)
test_metrics_all = evaluate_regression(y_test_all, y_test_pred_all)
print("A3: Linear Regression using all features")
print("\nTrain Set Metrics:")
print(f"MSE : {train_metrics_all[0]:.4f}")
print(f"RMSE: {train_metrics_all[1]:.4f}")
print(f"MAPE: {train_metrics_all[2]:.4f}")
print(f"R²  : {train_metrics_all[3]:.4f}")
print("\nTest Set Metrics:")
print(f"MSE : {test_metrics_all[0]:.4f}")
print(f"RMSE: {test_metrics_all[1]:.4f}")
print(f"MAPE: {test_metrics_all[2]:.4f}")
print(f"R²  : {test_metrics_all[3]:.4f}")
