import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score
RANDOM_STATE = 42
MAX_SAMPLE_FOR_METRICS = 2000  
df = pd.read_csv("GiveMeSomeCredit.csv")
df = df.dropna()
X_all = df.drop(columns=["SeriousDlqin2yrs"])
y_all = df["SeriousDlqin2yrs"]
X_train_all, X_test_all, y_train_all, y_test_all = train_test_split(
    X_all, y_all, test_size=0.2, random_state=RANDOM_STATE
)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_train_all)
n_total = X_scaled.shape[0]
sample_size = min(MAX_SAMPLE_FOR_METRICS, n_total)
rng = np.random.RandomState(RANDOM_STATE)
sample_idx = rng.choice(n_total, size=sample_size, replace=False)
X_cluster_sample = X_scaled[sample_idx]
def perform_kmeans(X_data, k):
    kmeans = KMeans(n_clusters=k, random_state=RANDOM_STATE, n_init=10)
    kmeans.fit(X_data)
    return kmeans

def clustering_metrics(X_data, labels):
    if len(np.unique(labels)) < 2:
        silhouette = float("nan")
    else:
        silhouette = silhouette_score(X_data, labels)
    ch_score = calinski_harabasz_score(X_data, labels)
    db_index = davies_bouldin_score(X_data, labels)
    return silhouette, ch_score, db_index

def evaluate_multiple_k(X_data, k_range):
    results = []
    for k in k_range:
        model = perform_kmeans(X_data, k)
        labels = model.labels_
        silhouette, ch, db = clustering_metrics(X_data, labels)
        results.append((k, silhouette, ch, db))
    return results
k_values = range(2, 11)
clustering_scores = evaluate_multiple_k(X_cluster_sample, k_values)
print(f"A6: Clustering Metrics for Different k values (sample size: {sample_size}/{n_total})")
for score in clustering_scores:
    print(f"k = {score[0]} --> Silhouette: {score[1]:.4f}, CH Score: {score[2]:.2f}, DB Index: {score[3]:.4f}")
