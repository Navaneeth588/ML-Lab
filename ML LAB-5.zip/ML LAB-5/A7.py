import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
RANDOM_STATE = 42
MAX_SAMPLE_FOR_PLOT = 2000  
df = pd.read_csv("GiveMeSomeCredit.csv")
df = df.dropna()
X_all = df.drop(columns=["SeriousDlqin2yrs"])
y_all = df["SeriousDlqin2yrs"]
X_train_all, X_test_all, y_train_all, y_test_all = train_test_split(
    X_all, y_all, test_size=0.2, random_state=RANDOM_STATE
)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_train_all)
n_total = X_scaled.shape[0]
sample_size = min(MAX_SAMPLE_FOR_PLOT, n_total)
rng = np.random.RandomState(RANDOM_STATE)
sample_idx = rng.choice(n_total, size=sample_size, replace=False)
X_cluster_sample = X_scaled[sample_idx]
def plot_elbow(X_data, k_range):
    distortions = []
    for k in k_range:
        kmeans = KMeans(n_clusters=k, random_state=RANDOM_STATE, n_init=10)
        kmeans.fit(X_data)
        distortions.append(kmeans.inertia_)
    plt.figure(figsize=(8, 5))
    plt.plot(k_range, distortions, marker='o')
    plt.title("Elbow Method")
    plt.xlabel("Number of Clusters (k)")
    plt.ylabel("Inertia")
    plt.grid(True)
    plt.show()
print(f"A7: Elbow plot for k=2 to 19 (sample size: {sample_size}/{n_total})")
plot_elbow(X_cluster_sample, range(2, 20))
