import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans
df = pd.read_csv("GiveMeSomeCredit.csv")
df = df.dropna()
X_all = df.drop(columns=["SeriousDlqin2yrs"])
y_all = df["SeriousDlqin2yrs"]
X_train_all, X_test_all, y_train_all, y_test_all = train_test_split(
    X_all, y_all, test_size=0.2, random_state=42
)
X_cluster = X_train_all.copy()
def perform_kmeans(X_data, k):
    kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
    kmeans.fit(X_data)
    return kmeans
kmeans_model = perform_kmeans(X_cluster, k=2)
cluster_labels = kmeans_model.labels_
cluster_centers = kmeans_model.cluster_centers_
print("A4: K-Means Clustering with k=2")
print("Cluster Centers:\n", cluster_centers)
print("Cluster Labels (first 10):", cluster_labels[:10])
