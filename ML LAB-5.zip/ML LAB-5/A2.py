import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error, r2_score
df = pd.read_csv("GiveMeSomeCredit.csv")
df = df.dropna()
X = df[["RevolvingUtilizationOfUnsecuredLines"]]
y = df["SeriousDlqin2yrs"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model_single = LinearRegression()
model_single.fit(X_train, y_train)
y_train_pred = model_single.predict(X_train)
y_test_pred = model_single.predict(X_test)
def evaluate_regression(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    rmse = mse ** 0.5  # Manual RMSE calculation
    mape = mean_absolute_percentage_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    return mse, rmse, mape, r2
train_metrics = evaluate_regression(y_train, y_train_pred)
test_metrics = evaluate_regression(y_test, y_test_pred)
print("A2: Evaluation Metrics (One Feature)")
print("\nTrain Set Metrics:")
print(f"MSE : {train_metrics[0]:.4f}")
print(f"RMSE: {train_metrics[1]:.4f}")
print(f"MAPE: {train_metrics[2]:.4f}")
print(f"R²  : {train_metrics[3]:.4f}")
print("\nTest Set Metrics:")
print(f"MSE : {test_metrics[0]:.4f}")
print(f"RMSE: {test_metrics[1]:.4f}")
print(f"MAPE: {test_metrics[2]:.4f}")
print(f"R²  : {test_metrics[3]:.4f}")
