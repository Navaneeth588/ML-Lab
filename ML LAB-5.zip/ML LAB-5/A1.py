import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
df = pd.read_csv("GiveMeSomeCredit.csv")
df = df.dropna()
X = df[["RevolvingUtilizationOfUnsecuredLines"]]
y = df["SeriousDlqin2yrs"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
# Function: train linear regression model with one feature
def train_linear_regression_single(X_train, y_train):
    model = LinearRegression()
    model.fit(X_train, y_train)
    return model
model_single = train_linear_regression_single(X_train, y_train)
y_train_pred = model_single.predict(X_train)
y_test_pred = model_single.predict(X_test)
print("A1: Linear Regression using one feature (RevolvingUtilizationOfUnsecuredLines)")
print("First 5 predicted values on training data:", y_train_pred[:5])
print("First 5 predicted values on test data:", y_test_pred[:5])
