import pandas as pd
import numpy as np
from collections import Counter
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import (
    silhouette_score,
    calinski_harabasz_score,
    davies_bouldin_score,
)
RANDOM_STATE = 42
MAX_SAMPLE_FOR_METRICS = 2000   
PCA_COMPONENTS = 10             
N_CLUSTERS = 2
df = pd.read_csv("GiveMeSomeCredit.csv")
df = df.dropna()  
X_all = df.drop(columns=["SeriousDlqin2yrs"], errors="ignore")
X_all = X_all.select_dtypes(include=[np.number])
if X_all.shape[0] == 0 or X_all.shape[1] == 0:
    raise ValueError("No numeric features found for clustering. Check your CSV/columns.")
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_all)
n_components = min(PCA_COMPONENTS, X_scaled.shape[1])
if n_components < X_scaled.shape[1]:
    pca = PCA(n_components=n_components, random_state=RANDOM_STATE)
    X_proc = pca.fit_transform(X_scaled)
else:
    X_proc = X_scaled
n_total = X_proc.shape[0]
sample_size = min(MAX_SAMPLE_FOR_METRICS, n_total)
rng = np.random.RandomState(RANDOM_STATE)
sample_idx = rng.choice(n_total, size=sample_size, replace=False)
X_sample = X_proc[sample_idx]
kmeans = KMeans(n_clusters=N_CLUSTERS, random_state=RANDOM_STATE, n_init=10)
kmeans.fit(X_sample)
labels = kmeans.labels_
centers = kmeans.cluster_centers_
cluster_counts = Counter(labels)
unique_labels = np.unique(labels)
if unique_labels.size < 2:
    silhouette = float("nan")
else:
    silhouette = silhouette_score(X_sample, labels)
ch_score = calinski_harabasz_score(X_sample, labels)
db_index = davies_bouldin_score(X_sample, labels)


print("A5 (fixed): Clustering Evaluation Metrics (computed on a sample)")
print(f"Total rows available : {n_total}")
print(f"Rows used for analysis: {sample_size}")
print(f"Features used (after PCA if applied): {X_sample.shape[1]}")
print()
print("KMeans (k={}):".format(N_CLUSTERS))
print("Cluster centers (shape {}):\n{}".format(centers.shape, centers))
print("Cluster counts:", dict(cluster_counts))
print()
print("Clustering metrics (computed on the sampled data):")
print(f"Silhouette Score       : {silhouette:.6f}")
print(f"Calinski-Harabasz Score: {ch_score:.6f}")
print(f"Davies-Bouldin Index   : {db_index:.6f}")
print()
print("Notes:")
print("- If you want exact metrics on the entire dataset, increase MAX_SAMPLE_FOR_METRICS or remove sampling.")
print("- Expect much longer runtime / higher memory usage for the full dataset.")
