import pandas as pd
df = pd.read_csv("GiveMeSomeCredit.csv")
df = df.dropna()
X = df.drop(columns=["SeriousDlqin2yrs"])
y = df["SeriousDlqin2yrs"]
from sklearn.metrics import confusion_matrix, classification_report

y_pred_test = knn3.predict(X_test)
y_pred_train = knn3.predict(X_train)

print("Classification Report (Test):")
print(classification_report(y_test, y_pred_test))

print("\nClassification Report (Train):")
print(classification_report(y_train, y_pred_train))

conf_matrix = confusion_matrix(y_test, y_pred_test)
print("\nConfusion Matrix (Test):\n", conf_matrix)