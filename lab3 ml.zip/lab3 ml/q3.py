import pandas as pd
df = pd.read_csv("GiveMeSomeCredit.csv")
df = df.dropna()
X = df.drop(columns=["SeriousDlqin2yrs"])
y = df["SeriousDlqin2yrs"]
vec1 = X.iloc[0].values
vec2 = X.iloc[1].values

minkowski_distances = [np.linalg.norm(vec1 - vec2, ord=r) for r in range(1, 11)]

plt.plot(range(1, 11), minkowski_distances, marker='o')
plt.title("Minkowski Distance (r = 1 to 10)")
plt.xlabel("r value")
plt.ylabel("Distance")
plt.grid(True)
plt.show()