import pandas as pd
df = pd.read_csv("GiveMeSomeCredit.csv")
df = df.dropna()
X = df.drop(columns=["SeriousDlqin2yrs"])
y = df["SeriousDlqin2yrs"]
from sklearn.neighbors import KNeighborsClassifier

knn3 = KNeighborsClassifier(n_neighbors=3)
knn3.fit(X_train, y_train)

print("kNN model trained with k=3.")