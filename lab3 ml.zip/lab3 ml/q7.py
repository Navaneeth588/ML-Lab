import pandas as pd
df = pd.read_csv("GiveMeSomeCredit.csv")
df = df.dropna()
X = df.drop(columns=["SeriousDlqin2yrs"])
y = df["SeriousDlqin2yrs"]
predictions = knn3.predict(X_test)
print("Sample Predictions:", predictions[:10])
print("Actual Labels:", y_test.values[:10])