import pandas as pd
df = pd.read_csv("GiveMeSomeCredit.csv")
df = df.dropna()
X = df.drop(columns=["SeriousDlqin2yrs"])
y = df["SeriousDlqin2yrs"]
accuracy = knn3.score(X_test, y_test)
print("Test set accuracy (k=3):", accuracy)