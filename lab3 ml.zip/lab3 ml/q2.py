import pandas as pd
df = pd.read_csv("GiveMeSomeCredit.csv")
df = df.dropna()
X = df.drop(columns=["SeriousDlqin2yrs"])
y = df["SeriousDlqin2yrs"]
import matplotlib.pyplot as plt

feature = 'RevolvingUtilizationOfUnsecuredLines'
data = df[feature]

plt.hist(data, bins=50, color='teal', edgecolor='black')
plt.title(f"Histogram of {feature}")
plt.xlabel("Value")
plt.ylabel("Frequency")
plt.show()

print("Mean:", np.mean(data))
print("Variance:", np.var(data))