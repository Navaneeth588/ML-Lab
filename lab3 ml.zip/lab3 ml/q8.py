import pandas as pd
df = pd.read_csv("GiveMeSomeCredit.csv")
df = df.dropna()
X = df.drop(columns=["SeriousDlqin2yrs"])
y = df["SeriousDlqin2yrs"]
k_values = list(range(1, 12))
accuracies = []

for k in k_values:
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    acc = knn.score(X_test, y_test)
    accuracies.append(acc)

plt.plot(k_values, accuracies, marker='o')
plt.title("kNN Accuracy vs k (1 to 11)")
plt.xlabel("k")
plt.ylabel("Accuracy")
plt.grid(True)
plt.show()