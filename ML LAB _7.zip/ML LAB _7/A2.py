# === Import Required Libraries ===
import pandas as pd
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import classification_report

# === Load Dataset ===
df = pd.read_csv("GiveMeSomeCredit .csv")

# Define predictors and response
y_col = "SeriousDlqin2yrs"
X_data = df.drop(columns=[y_col])
y_data = df[y_col]

# === Handle Missing Values (median imputation) ===
filler = SimpleImputer(strategy="median")
X_filled = filler.fit_transform(X_data)

# === Create Train-Test Partitions ===
X_tr, X_te, y_tr, y_te = train_test_split(
    X_filled, y_data, test_size=0.25, random_state=101
)

# === Random Forest with Hyperparameter Search ===
param_grid = {
    "n_estimators": [80, 120, 250],
    "max_depth": [None, 8, 16, 24],
    "min_samples_split": [2, 4, 8]
}

forest_clf = RandomForestClassifier(random_state=101)
random_search = RandomizedSearchCV(
    estimator=forest_clf,
    param_distributions=param_grid,
    n_iter=8,
    cv=4,
    random_state=101,
    n_jobs=-1
)

random_search.fit(X_tr, y_tr)

# === Results ===
print("Optimal Parameters Found:\n", random_search.best_params_)
y_predicted = random_search.predict(X_te)
print("\nClassification Report on Test Data:\n")
print(classification_report(y_te, y_predicted))
