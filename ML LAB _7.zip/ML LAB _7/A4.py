# === Libraries ===
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from xgboost import XGBRegressor
from sklearn.impute import SimpleImputer

# === Load Data ===
df = pd.read_csv("GiveMeSomeCredit .csv")

# Target column (predicting a feature as regression task)
y_target = df["RevolvingUtilizationOfUnsecuredLines"]
X_features = df.drop(columns=["RevolvingUtilizationOfUnsecuredLines"])

# === Impute Missing Values ===
median_fill = SimpleImputer(strategy="median")
X_features = median_fill.fit_transform(X_features)

# === Train-Test Split ===
X_train, X_test, y_train, y_test = train_test_split(
    X_features, y_target, test_size=0.2, random_state=55
)

# === Models to Compare ===
regressors = {
    "LinearReg": LinearRegression(),
    "RandomForestReg": RandomForestRegressor(n_estimators=120, random_state=55),
    "GBReg": GradientBoostingRegressor(n_estimators=150, learning_rate=0.08),
    "XGBReg": XGBRegressor(n_estimators=100, learning_rate=0.1)
}

# === Train & Evaluate ===
for reg_name, reg in regressors.items():
    reg.fit(X_train, y_train)
    predictions = reg.predict(X_test)
    mse = mean_squared_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)
    print(f"{reg_name}: MSE = {mse:.5f}, R² = {r2:.5f}")
