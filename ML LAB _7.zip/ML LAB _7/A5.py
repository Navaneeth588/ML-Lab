# === Libraries ===
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import AgglomerativeClustering, KMeans, MiniBatchKMeans
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer

# === Load Data ===
df = pd.read_csv("GiveMeSomeCredit .csv")
X_vals = df.drop(columns=["SeriousDlqin2yrs"])

# === Handle Missing Values ===
fill_missing = SimpleImputer(strategy="median")
X_filled = fill_missing.fit_transform(X_vals)

# === Standardization ===
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_filled)

# === Dimensionality Reduction (PCA) ===
n_features = X_scaled.shape[1]
pca = PCA(n_components=min(10, n_features), random_state=202)
X_pca = pca.fit_transform(X_scaled)

# === Subset for Hierarchical Clustering (performance reasons) ===
subset_data = X_pca[:2500]

# Agglomerative Clustering
agg_cluster = AgglomerativeClustering(n_clusters=4)
labels_agg = agg_cluster.fit_predict(subset_data)

# KMeans
kmeans_clf = KMeans(n_clusters=4, random_state=202)
labels_kmeans = kmeans_clf.fit_predict(X_pca)

# MiniBatchKMeans
mini_kmeans = MiniBatchKMeans(n_clusters=4, batch_size=800, random_state=202)
labels_mini = mini_kmeans.fit_predict(X_pca)

print("Sample Agglomerative Labels:", labels_agg[:15])
print("Sample KMeans Labels:", labels_kmeans[:15])
print("Sample MiniBatchKMeans Labels:", labels_mini[:15])
