# === Libraries ===
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
from sklearn.impute import SimpleImputer

# Try importing XGBoost safely
try:
    from xgboost import XGBClassifier
    has_xgb = True
except ImportError:
    print("⚠️ XGBoost not available, skipping it.")
    has_xgb = False

# === Load Data ===
df = pd.read_csv("GiveMeSomeCredit .csv")
target = "SeriousDlqin2yrs"
X = df.drop(columns=[target])
y = df[target]

# === Handle Missing Values ===
imputer = SimpleImputer(strategy="median")
X = imputer.fit_transform(X)

# === Split ===
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.25, random_state=123
)

# === Models (except SVM, we handle separately) ===
models = {
    "DecisionTree": DecisionTreeClassifier(max_depth=6),
    "RandomForest": RandomForestClassifier(n_estimators=150, random_state=123),
    "AdaBoost": AdaBoostClassifier(n_estimators=80),
    "NaiveBayes": GaussianNB(),
    "MLP": MLPClassifier(max_iter=600, hidden_layer_sizes=(50, 30))
}

if has_xgb:
    models["XGBoost"] = XGBClassifier(use_label_encoder=False, eval_metric="logloss")

# === Train & Evaluate ===
results = []

# Handle SVM separately on smaller subset
sample_size = 10000
X_small, y_small = X_tr[:sample_size], y_tr[:sample_size]
svc = SVC(kernel="rbf", gamma="scale")
svc.fit(X_small, y_small)
y_pred_svm = svc.predict(X_te)
results.append([
    "SVM (10k subset)",
    accuracy_score(y_te, y_pred_svm),
    precision_score(y_te, y_pred_svm),
    recall_score(y_te, y_pred_svm),
    f1_score(y_te, y_pred_svm)
])

# Train other models on full dataset
for name, clf in models.items():
    clf.fit(X_tr, y_tr)
    y_pred = clf.predict(X_te)
    results.append([
        name,
        accuracy_score(y_te, y_pred),
        precision_score(y_te, y_pred),
        recall_score(y_te, y_pred),
        f1_score(y_te, y_pred)
    ])

# === Results as DataFrame ===
results_df = pd.DataFrame(results, columns=["Model", "Accuracy", "Precision", "Recall", "F1"])
print(results_df)
