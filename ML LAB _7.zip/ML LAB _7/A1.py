# --- Libraries ---
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.impute import SimpleImputer
from sklearn.metrics import classification_report

# --- Load Data ---
df = pd.read_csv("GiveMeSomeCredit .csv")

# Separate target and features
target = "SeriousDlqin2yrs"
features = df.drop(columns=[target])
labels = df[target]

# --- Handle Missing Values ---
median_imputer = SimpleImputer(strategy="median")
features_imputed = median_imputer.fit_transform(features)

# --- Train-Test Split ---
train_X, test_X, train_y, test_y = train_test_split(
    features_imputed, labels, test_size=0.25, random_state=123
)

# --- Build Model ---
log_reg = LogisticRegression(solver="lbfgs", max_iter=1200)
log_reg.fit(train_X, train_y)

# --- Predictions & Evaluation ---
predictions = log_reg.predict(test_X)
report = classification_report(test_y, predictions)
print("Classification Report:\n")
print(report)
