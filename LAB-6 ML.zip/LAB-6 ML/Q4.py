import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
df = pd.read_csv("GiveMeSomeCredit.csv")

def binning(series, bins=4, method='equal_width'):
    if method == 'equal_width':
        return pd.cut(series, bins=bins, labels=False)
    elif method == 'frequency':
        return pd.qcut(series, q=bins, labels=False)
    else:
        raise ValueError("Method should be 'equal_width' or 'frequency'")

def calculate_similarity(col1, col2):
    counts1 = col1.value_counts(normalize=True).sort_index()
    counts2 = col2.value_counts(normalize=True).sort_index()
    all_index = counts1.index.union(counts2.index)
    vec1 = counts1.reindex(all_index, fill_value=0).values.reshape(1, -1)
    vec2 = counts2.reindex(all_index, fill_value=0).values.reshape(1, -1)
    return cosine_similarity(vec1, vec2)[0][0]
col_to_bin = 'age'
df[col_to_bin] = binning(df[col_to_bin], bins=5, method='frequency')

print(df[[col_to_bin]].head())

target_col = 'SeriousDlqin2yrs'
if target_col in df.columns:
    similarity_value = calculate_similarity(df[col_to_bin], df[target_col])
    print(f"\nSimilarity between {col_to_bin} and {target_col}: {similarity_value:.4f}")
