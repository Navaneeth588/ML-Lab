import pandas as pd
import numpy as np
from math import log2
from sklearn.metrics.pairwise import cosine_similarity

df = pd.read_csv("GiveMeSomeCredit.csv")

target_col = 'SeriousDlqin2yrs'

def equal_width_binning(series, bins=4):
    return pd.cut(series, bins=bins, labels=False)

if df[target_col].nunique() > 10:  
    df[target_col] = equal_width_binning(df[target_col])

def calculate_entropy(series):
    counts = series.value_counts()
    total = len(series)
    entropy = 0
    for count in counts:
        p = count / total
        entropy -= p * log2(p)
    return entropy

def calculate_similarity(col1, col2):
    counts1 = col1.value_counts(normalize=True).sort_index()
    counts2 = col2.value_counts(normalize=True).sort_index()

    all_index = counts1.index.union(counts2.index)
    vec1 = counts1.reindex(all_index, fill_value=0).values.reshape(1, -1)
    vec2 = counts2.reindex(all_index, fill_value=0).values.reshape(1, -1)

    return cosine_similarity(vec1, vec2)[0][0]

entropy_value = calculate_entropy(df[target_col])
print(f"Entropy of {target_col}: {entropy_value:.4f}")

if 'age' in df.columns:
    sim_value = calculate_similarity(df[target_col], df['age'])
    print(f"Similarity between {target_col} and age: {sim_value:.4f}")
