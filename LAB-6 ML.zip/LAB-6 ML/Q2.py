import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

df = pd.read_csv("GiveMeSomeCredit.csv")

target_col = 'SeriousDlqin2yrs'

def calculate_gini(series):
    counts = series.value_counts()
    total = len(series)
    gini = 1 - sum((count / total) ** 2 for count in counts)
    return gini

def calculate_similarity(col1, col2):
    counts1 = col1.value_counts(normalize=True).sort_index()
    counts2 = col2.value_counts(normalize=True).sort_index()

    all_index = counts1.index.union(counts2.index)
    vec1 = counts1.reindex(all_index, fill_value=0).values.reshape(1, -1)
    vec2 = counts2.reindex(all_index, fill_value=0).values.reshape(1, -1)

    return cosine_similarity(vec1, vec2)[0][0]

gini_value = calculate_gini(df[target_col])
print(f"Gini Index of {target_col}: {gini_value:.4f}")

if 'age' in df.columns:
    sim_value = calculate_similarity(df[target_col], df['age'])
    print(f"Similarity between {target_col} and age: {sim_value:.4f}")
