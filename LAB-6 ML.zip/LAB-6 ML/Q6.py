import pandas as pd
from sklearn.tree import DecisionTreeClassifier, plot_tree
import matplotlib.pyplot as plt
from sklearn.metrics.pairwise import cosine_similarity
df = pd.read_csv("GiveMeSomeCredit.csv")
target_col = 'SeriousDlqin2yrs'
X = df.drop(columns=[target_col]).select_dtypes(include=['number']).fillna(0)
y = df[target_col]
clf = DecisionTreeClassifier(max_depth=3, random_state=42)
clf.fit(X, y)
plt.figure(figsize=(20, 10))
plot_tree(clf, feature_names=X.columns, class_names=['No', 'Yes'], filled=True)
plt.show()
def calculate_similarity(feature, target):
    counts1 = feature.value_counts(normalize=True).sort_index()
    counts2 = target.value_counts(normalize=True).sort_index()
    all_index = counts1.index.union(counts2.index)
    vec1 = counts1.reindex(all_index, fill_value=0).values.reshape(1, -1)
    vec2 = counts2.reindex(all_index, fill_value=0).values.reshape(1, -1)
    return cosine_similarity(vec1, vec2)[0][0]
similarities = {col: calculate_similarity(X[col], y) for col in X.columns}
print("\nFeature Similarities with Target (cosine):")
for feature, sim in similarities.items():
    print(f"{feature}: {sim:.4f}")
