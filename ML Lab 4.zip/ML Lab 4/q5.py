import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier

# Generate synthetic training data (20 samples, 2D points)
np.random.seed(42)
train_data = np.random.uniform(low=1, high=10, size=(20, 2))
train_labels = np.random.randint(0, 2, size=20)

# Create a dense 2D grid for testing
grid_x = np.linspace(0, 10, 101)
grid_y = np.linspace(0, 10, 101)
grid_X, grid_Y = np.meshgrid(grid_x, grid_y)
test_data = np.column_stack((grid_X.ravel(), grid_Y.ravel()))

# Loop over multiple k values and visualize classification regions
for neighbors in [1, 3, 5, 7, 9]:
    # Train k-NN classifier
    model = KNeighborsClassifier(n_neighbors=neighbors)
    model.fit(train_data, train_labels)

    # Predict on grid
    predictions = model.predict(test_data)

    # Plotting
    plt.figure(figsize=(6, 5))
    plt.scatter(
        test_data[:, 0], test_data[:, 1],
        c=predictions,
        cmap="coolwarm",
        alpha=0.25,
        s=16
    )
    plt.scatter(
        train_data[:, 0], train_data[:, 1],
        c=train_labels,
        cmap="coolwarm",
        edgecolors="black",
        s=75,
        linewidths=1
    )
    plt.title(f"k-NN Classifier (k = {neighbors})", fontsize=12)
    plt.xlabel("X-axis Feature")
    plt.ylabel("Y-axis Feature")
    plt.grid(True, linestyle="--", linewidth=0.5)
    plt.tight_layout()
    plt.show()
