import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

# Load the credit dataset
data = pd.read_csv("GiveMeSomeCredit.csv")

# Select two features for visualization
selected_features = ["age", "DebtRatio"]
X_selected = data[selected_features].dropna().values
y_target = data["SeriousDlqin2yrs"].dropna().values

# Split: small train set (10%) to visualize decision boundary clearly
X_train, X_test, y_train, y_test = train_test_split(
    X_selected, y_target, test_size=0.90, random_state=42
)

# Train k-NN model with k=5
knn_model = KNeighborsClassifier(n_neighbors=5)
knn_model.fit(X_train, y_train)

# Generate a mesh grid to visualize decision regions
x_range = np.linspace(X_selected[:, 0].min(), X_selected[:, 0].max(), 200)
y_range = np.linspace(X_selected[:, 1].min(), X_selected[:, 1].max(), 200)
grid_x, grid_y = np.meshgrid(x_range, y_range)
grid_points = np.column_stack((grid_x.ravel(), grid_y.ravel()))

# Predict the class on the grid
grid_predictions = knn_model.predict(grid_points)

# Visualization
plt.figure(figsize=(7, 6))
plt.contourf(grid_x, grid_y, grid_predictions.reshape(grid_x.shape), cmap="coolwarm", alpha=0.25)
plt.scatter(
    X_train[:, 0],
    X_train[:, 1],
    c=y_train,
    cmap="coolwarm",
    edgecolors="black",
    s=70,
    linewidths=0.7
)

plt.title("k-NN Decision Boundary (Using Real Dataset)", fontsize=13)
plt.xlabel(selected_features[0])
plt.ylabel(selected_features[1])
plt.grid(True, linestyle="--", linewidth=0.5)
plt.tight_layout()
plt.show()
