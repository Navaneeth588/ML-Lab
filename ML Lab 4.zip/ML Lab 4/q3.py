import numpy as np
import matplotlib.pyplot as plt

# Set a fixed seed for reproducibility
np.random.seed(42)

# Create synthetic dataset with 2 features and binary class labels
features = np.random.uniform(low=1, high=10, size=(20, 2))
labels = np.random.randint(0, 2, size=20)

# Plotting the data points with color indicating class
plt.figure(figsize=(6, 5))
scatter = plt.scatter(
    features[:, 0],
    features[:, 1],
    c=labels,
    cmap='coolwarm',
    s=60,
    edgecolor='black',
    alpha=0.9
)

plt.title("Synthetic Training Data (20 Samples)", fontsize=12)
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.grid(True, linestyle="--", linewidth=0.5)
plt.tight_layout()
plt.show()
