import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier

# Set seed and generate random 2D data points
np.random.seed(42)
train_points = np.random.uniform(1, 10, size=(20, 2))
class_labels = np.random.randint(0, 2, size=20)

# Generate a grid of points over the 2D feature space
x_range = np.linspace(0, 10, 101)
y_range = np.linspace(0, 10, 101)
grid_x, grid_y = np.meshgrid(x_range, y_range)
grid_points = np.column_stack((grid_x.ravel(), grid_y.ravel()))

# Initialize and train the KNN classifier
knn_model = KNeighborsClassifier(n_neighbors=3)
knn_model.fit(train_points, class_labels)

# Predict the class for each point in the grid
grid_predictions = knn_model.predict(grid_points)

# Visualization
plt.figure(figsize=(7, 6))
plt.scatter(
    grid_points[:, 0],
    grid_points[:, 1],
    c=grid_predictions,
    cmap="coolwarm",
    alpha=0.25,
    s=15
)

plt.scatter(
    train_points[:, 0],
    train_points[:, 1],
    c=class_labels,
    cmap="coolwarm",
    edgecolors="black",
    s=70,
    linewidths=1.2
)

plt.title("k-Nearest Neighbors (k=3) Decision Regions", fontsize=12)
plt.xlabel("Feature A")
plt.ylabel("Feature B")
plt.grid(True, linestyle=':', linewidth=0.7)
plt.tight_layout()
plt.show()
